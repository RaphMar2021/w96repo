alert("To complete installation of the Windows 10 theme, Windows 96 needs to reboot.");
w96.sys.reboot();
