# Windows 10 theme

This is a theme to have the Windows 10 style on Windows 96.

## For devs

The Windows 10 theme include some blur effects.

Here is a sample code to replicate that effect :

```css
background-color: rgba(211, 211, 211, 0.44);
backdrop-filter: blur(30px);
```

If you want a dark mode blur, replace the background color with : ```rgba(84, 84, 84, 0.64)```