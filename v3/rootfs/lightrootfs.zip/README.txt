Windows 96 Light Image

This is a light rootfs for Windows 96.
